@echo off
setlocal
set "source=%~dp0Computer_Lab_V68"
set "dest=%USERPROFILE%\.blockcraft112\saves\Computer_Lab_V68"
echo Computer Lab - local world installer
echo Close Blockcraft before continuing.
echo This only copies the new world. It does not change game options or other saves.
echo.
if not exist "%source%\level.properties" (
  echo ERROR: Extract the WHOLE ZIP first. The world folder is missing.
  pause
  exit /b 1
)
if exist "%dest%" (
  echo NOT INSTALLED: A world already exists at:
  echo "%dest%"
  echo Rename that existing folder if you want a fresh copy. Nothing was overwritten.
  pause
  exit /b 1
)
choice /C YN /N /M "Install this new world into your default Blockcraft saves? [Y/N] "
if errorlevel 2 exit /b 0
robocopy "%source%" "%dest%" /E /COPY:DAT /R:1 /W:1 /NFL /NDL /NJH /NJS
if errorlevel 8 (
  echo Copy failed. Check folder permissions and use the manual instructions.
  pause
  exit /b 1
)
echo.
echo Installed. Open Blockcraft V6.8, then Singleplayer:
echo Computer Lab - 4-bit PC and Calculator
echo Use render distance 5 or higher. The CPU is already running.
pause
exit /b 0
