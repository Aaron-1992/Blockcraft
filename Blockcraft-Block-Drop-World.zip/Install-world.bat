@echo off
setlocal
cd /d "%~dp0"
set "DEST=%USERPROFILE%\.blockcraft112\saves\Block_Drop_V69"
if not exist "Block_Drop_V69\level.properties" goto missing
if not exist "Block_Drop_V69\raster.dat" goto missing
if exist "%DEST%" goto exists
echo Requires Blockcraft V6.9 or later. Close the game before installing.
echo This copies the world to:
echo %DEST%
choice /C YN /N /M "Install this NEW world? [Y/N] "
if errorlevel 2 exit /b 0
mkdir "%DEST%"
if errorlevel 1 goto failed
xcopy "Block_Drop_V69\*" "%DEST%\" /E /I /H /K /Y
if errorlevel 1 goto failed
echo Installed. Open Singleplayer in Blockcraft V6.9.
echo Right-click the keypad on your left, then press ENTER.
pause
exit /b 0
:missing
echo Extract the WHOLE zip first; the native world files are missing.
pause
exit /b 1
:exists
echo Not installed: that world already exists. Nothing was replaced.
echo Back up or rename the existing world if you want a fresh copy.
pause
exit /b 1
:failed
echo Copy failed. Check permissions and available disk space.
echo A partial NEW folder may remain; no existing world was overwritten.
pause
exit /b 1
