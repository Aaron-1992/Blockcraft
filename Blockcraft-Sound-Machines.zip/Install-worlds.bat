@echo off
setlocal
cd /d "%~dp0"
set "BASE=%USERPROFILE%\.blockcraft112\saves"
for %%W in (Shadow_Signal_V610 Block_Drop_Sound_V610) do (
  if not exist "%%W\level.properties" goto missing
  if not exist "%%W\raster.dat" goto missing
  if exist "%BASE%\%%W" goto exists
)
echo Requires Blockcraft V6.10. Close the game before installing.
echo This installs TWO NEW worlds in %BASE%
echo Your existing V6.9 world is not replaced.
choice /C YN /N /M "Install these NEW worlds? [Y/N] "
if errorlevel 2 exit /b 0
for %%W in (Shadow_Signal_V610 Block_Drop_Sound_V610) do (
  mkdir "%BASE%\%%W"
  if errorlevel 1 goto failed
  xcopy "%%W\*" "%BASE%\%%W\" /E /I /H /K /Y
  if errorlevel 1 goto failed
)
echo Installed. Open Singleplayer in Blockcraft V6.10.
echo Right-click the keypad on your left, then ENTER. M mutes. ESC leaves.
pause
exit /b 0
:missing
echo Extract the WHOLE zip first. Native world files are missing.
pause
exit /b 1
:exists
echo Not installed: at least one destination already exists. NOTHING was replaced.
echo Back up or rename that destination yourself before installing a fresh copy.
pause
exit /b 1
:failed
echo Copy failed. Check permissions and disk space. Partial NEW folders may remain.
echo No pre-existing world was overwritten.
pause
exit /b 1
